# On-Device Scam Shield — PS-04

## Run
- Install Python 3.9 or newer.
- No pip packages or internet connection are required.
- Windows: double-click `run_windows.bat`, or run `python scam_shield.py`.
- macOS/Linux: run `python3 scam_shield.py` (Tkinter must be included with Python).

## What it does
- Trains a tiny multinomial Naive Bayes text classifier from a small local demo corpus at startup.
- Adds explainable signals for urgency, requests for OTP/PIN/password/money, and suspicious links.
- Displays a 0–100 heuristic risk score, level, reasons, and safe next steps.
- Runs entirely on the device; the prototype contains no network code.

## Important limitations
This is a classroom prototype, not a production-grade detector. The demo corpus is small and synthetic, so scores are not calibrated probabilities and false positives/negatives are possible. It analyses pasted text; it does not intercept SMS, inspect websites, or analyse calls. Do not use it as the sole basis for financial decisions. A real deployment needs representative multilingual datasets, robust model evaluation, signed model updates, accessibility testing, and platform permissions/security review.

## Suggested demo
1. Start the app and analyse the preloaded bank/OTP/short-link example.
2. Select **Load safe example** and compare the result.
3. Try a new message with an unfamiliar wording and discuss how the model plus signals respond.
4. Explain that all processing happens locally and the message is not uploaded.

## Architecture
Message input -> local tokenization + Naive Bayes model -> URL/social-engineering signal checks -> risk score + explanation -> user guidance.
