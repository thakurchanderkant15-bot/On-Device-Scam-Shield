"""
On-Device Scam Shield — PS-04 prototype
Python 3.9+ | Standard library only | Offline after download/copy

This is an educational prototype, not a production fraud detector.
It trains a small Naive Bayes text classifier from local example data at
startup, combines the model score with explainable URL/social-engineering
signals, and never sends message content to a server.
"""
from __future__ import annotations
import math
import re
import tkinter as tk
from tkinter import ttk, messagebox
from urllib.parse import urlparse
from collections import Counter, defaultdict

# Small, locally stored demonstration corpus. Extend with consented, labelled
# examples for a real deployment. No user messages are used for training.
TRAINING_DATA = [
    ("scam", "Your bank account is blocked verify now using this link"),
    ("scam", "Congratulations you won a prize pay processing fee to claim"),
    ("scam", "Urgent KYC update required click link or account suspended"),
    ("scam", "Your parcel is held pay customs fee immediately"),
    ("scam", "Police case registered pay fine now to avoid arrest"),
    ("scam", "I am your son lost my phone send money to this new number"),
    ("scam", "Your electricity will be disconnected today pay bill here"),
    ("scam", "Investment guaranteed double return send money today"),
    ("scam", "Share OTP to receive refund and verify your identity"),
    ("scam", "Dear customer unusual activity login here to secure account"),
    ("scam", "You have been selected for a cash reward claim immediately"),
    ("scam", "Your SIM will be deactivated update details at this website"),
    ("scam", "Pay small fee now to release your package"),
    ("scam", "This is support team install remote access app for help"),
    ("scam", "Keep this confidential transfer money to safe account"),
    ("scam", "Your card is blocked call this number and share PIN"),
    ("scam", "Tax refund pending enter bank details to get refund"),
    ("scam", "Act now limited offer send deposit to reserve your prize"),
    ("scam", "We detected a problem click the shortened link and login"),
    ("scam", "Your wallet is frozen confirm password and one time code"),
    ("legit", "Your appointment is confirmed for tomorrow at ten am"),
    ("legit", "The library will remain closed on Sunday"),
    ("legit", "Your order has been shipped and is arriving Friday"),
    ("legit", "Hi are we still meeting for lunch at one"),
    ("legit", "Your monthly statement is ready in the official bank app"),
    ("legit", "Your electricity bill is available in the provider app"),
    ("legit", "The school meeting starts at four pm in room two"),
    ("legit", "Thanks for your payment your receipt is attached"),
    ("legit", "Please call me when you reach home"),
    ("legit", "Your parcel delivery is scheduled for tomorrow"),
    ("legit", "The event registration is confirmed thank you"),
    ("legit", "Your password was changed successfully if this was you"),
    ("legit", "Your subscription renews next month manage it in settings"),
    ("legit", "The train is delayed by fifteen minutes"),
    ("legit", "Your friend shared photos from the weekend"),
    ("legit", "Your report is ready for collection from the office"),
    ("legit", "The meeting agenda is attached for your review"),
    ("legit", "Your recharge was successful thank you"),
    ("legit", "Please review the class notes before tomorrow"),
    ("legit", "Your grocery order is ready for pickup"),
]

URL_RE = re.compile(r'(?i)\b(?:https?://|www\.)[^\s<>()]+')
SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "is.gd", "cutt.ly", "rb.gy"}
SUSPICIOUS_TERMS = {
    "urgent": 9, "immediately": 8, "otp": 18, "pin": 12, "password": 13,
    "blocked": 10, "suspended": 9, "verify": 7, "click": 6, "prize": 8,
    "winner": 8, "refund": 7, "transfer": 10, "confidential": 8,
    "arrest": 10, "deactivated": 9, "remote access": 14, "safe account": 12,
    "processing fee": 10, "limited time": 6, "act now": 7
}

def tokenize(text):
    return re.findall(r"[a-z0-9]+", text.lower())

class LocalNaiveBayes:
    """Tiny multinomial Naive Bayes text model; all computation is local."""
    def __init__(self):
        self.docs = Counter()
        self.words = defaultdict(Counter)
        self.vocab = set()

    def fit(self, rows):
        for label, text in rows:
            self.docs[label] += 1
            tokens = tokenize(text)
            self.words[label].update(tokens)
            self.vocab.update(tokens)

    def scam_probability(self, text):
        labels = ("scam", "legit")
        total_docs = sum(self.docs.values())
        vocab_size = max(1, len(self.vocab))
        scores = {}
        for label in labels:
            # Laplace-smoothed prior and token likelihood.
            score = math.log((self.docs[label] + 1) / (total_docs + 2))
            denom = sum(self.words[label].values()) + vocab_size
            for token in tokenize(text):
                score += math.log((self.words[label][token] + 1) / denom)
            scores[label] = score
        top = max(scores.values())
        probs = {k: math.exp(v - top) for k, v in scores.items()}
        return probs["scam"] / sum(probs.values())

MODEL = LocalNaiveBayes()
MODEL.fit(TRAINING_DATA)

def analyse_message(message):
    """Return risk 0-100, category, reasons, and safe next steps."""
    text = message.strip()
    if not text:
        return {"risk": 0, "level": "No message", "reasons": ["Enter a message to analyse."],
                "advice": ["Paste or type a message, then select Analyse."]}
    prob = MODEL.scam_probability(text)
    # Model probability is a signal, not a calibrated real-world probability.
    score = int(prob * 55)
    lower = text.lower()
    reasons = []
    for phrase, points in SUSPICIOUS_TERMS.items():
        if phrase in lower:
            score += points
            reasons.append(f"Pressure or sensitive-data signal: “{phrase}” (+{points})")
    urls = URL_RE.findall(text)
    for raw in urls:
        cleaned = raw.rstrip(".,!?;:)")
        host = urlparse(cleaned if cleaned.startswith("http") else "http://" + cleaned).netloc.lower()
        host = host.split("@")[-1].split(":")[0]
        if host in SHORTENERS:
            score += 18
            reasons.append(f"Shortened link hides its final destination: {host} (+18)")
        elif host and not any(host.endswith(x) for x in (".gov.in", ".gov", ".edu")):
            score += 5
            reasons.append(f"External link detected: {host} (+5); verify it independently")
        if re.search(r'(?i)(\d{1,3}\.){3}\d{1,3}', host):
            score += 15
            reasons.append("Link uses a raw IP address (+15)")
    # Multiple urgency/sensitive requests can indicate social engineering.
    if any(x in lower for x in ("send otp", "share otp", "share pin", "send money")):
        score += 15
        reasons.append("Direct request for money or authentication secret (+15)")
    score = min(100, score)
    if score >= 70:
        level = "HIGH RISK"
    elif score >= 40:
        level = "CAUTION"
    else:
        level = "LOWER RISK"
    if not reasons:
        reasons.append("No strong scam indicators were detected by this small demo model.")
    advice = []
    if score >= 40:
        advice = [
            "Do not click links or call numbers in the message.",
            "Never share OTP, PIN, password, or remote-access permissions.",
            "Verify using the official app, website, or a number you already trust.",
            "If money was lost, contact your bank immediately and report the incident."
        ]
    else:
        advice = [
            "Check the sender and context before acting.",
            "Open services through their official app or a saved bookmark.",
            "A low score does not prove a message is safe."
        ]
    return {"risk": score, "level": level, "reasons": reasons, "advice": advice}

class ScamShieldApp:
    def __init__(self, root):
        self.root = root
        root.title("On-Device Scam Shield | PS-04")
        root.geometry("850x700")
        root.minsize(700, 600)
        root.configure(bg="#f3f6fb")
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TButton", font=("Segoe UI", 10, "bold"), padding=8)
        style.configure("TLabel", background="#f3f6fb", font=("Segoe UI", 10))
        style.configure("Header.TLabel", font=("Segoe UI", 22, "bold"), foreground="#14213d")
        style.configure("Sub.TLabel", font=("Segoe UI", 10), foreground="#526078")
        style.configure("TLabelframe", background="#ffffff")
        style.configure("TLabelframe.Label", background="#ffffff", font=("Segoe UI", 11, "bold"))
        outer = tk.Frame(root, bg="#f3f6fb", padx=24, pady=20)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="ON-DEVICE SCAM SHIELD", style="Header.TLabel").pack(anchor="w")
        ttk.Label(outer, text="Private, offline-first message risk screening • PS-04 prototype",
                  style="Sub.TLabel").pack(anchor="w", pady=(2, 14))
        panel = tk.Frame(outer, bg="#ffffff", padx=16, pady=14,
                         highlightbackground="#dce3ef", highlightthickness=1)
        panel.pack(fill="both", expand=True)
        tk.Label(panel, text="Paste a suspicious SMS or message", bg="#ffffff",
                 fg="#14213d", font=("Segoe UI", 12, "bold")).pack(anchor="w")
        self.input = tk.Text(panel, height=7, wrap="word", font=("Segoe UI", 11),
                             relief="solid", bd=1, padx=10, pady=8)
        self.input.pack(fill="x", pady=(8, 10))
        self.input.insert("1.0", "URGENT: Your bank account is blocked. Verify now and share OTP at http://bit.ly/example")
        actions = tk.Frame(panel, bg="#ffffff")
        actions.pack(fill="x")
        ttk.Button(actions, text="Analyse message", command=self.run_analysis).pack(side="left")
        ttk.Button(actions, text="Clear", command=self.clear).pack(side="left", padx=8)
        ttk.Button(actions, text="Load safe example", command=self.safe_example).pack(side="left")
        self.result = tk.Frame(panel, bg="#ffffff")
        self.result.pack(fill="both", expand=True, pady=(16, 0))
        self.status = tk.Label(self.result, text="Ready to analyse locally", bg="#ffffff",
                               fg="#526078", font=("Segoe UI", 12, "bold"))
        self.status.pack(anchor="w")
        self.score = tk.Label(self.result, text="Risk score: —", bg="#ffffff",
                              fg="#14213d", font=("Segoe UI", 18, "bold"))
        self.score.pack(anchor="w", pady=(4, 8))
        self.bar = ttk.Progressbar(self.result, maximum=100, length=600, mode="determinate")
        self.bar.pack(fill="x", pady=(0, 12))
        tk.Label(self.result, text="Why it was flagged", bg="#ffffff", fg="#14213d",
                 font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.reasons = tk.Text(self.result, height=5, wrap="word", font=("Segoe UI", 10),
                               relief="flat", bg="#f7f9fc", padx=8, pady=6)
        self.reasons.pack(fill="x", pady=(4, 10))
        tk.Label(self.result, text="Recommended action", bg="#ffffff", fg="#14213d",
                 font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.advice = tk.Text(self.result, height=5, wrap="word", font=("Segoe UI", 10),
                              relief="flat", bg="#f7f9fc", padx=8, pady=6)
        self.advice.pack(fill="x", pady=(4, 8))
        tk.Label(outer, text="Privacy: message text stays on this device. No network calls or cloud upload.",
                 bg="#f3f6fb", fg="#24704a", font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(10, 0))
        self.run_analysis()

    def clear(self):
        self.input.delete("1.0", "end")
        self.status.config(text="Ready to analyse locally", fg="#526078")
        self.score.config(text="Risk score: —")
        self.bar["value"] = 0
        for widget in (self.reasons, self.advice):
            widget.delete("1.0", "end")

    def safe_example(self):
        self.input.delete("1.0", "end")
        self.input.insert("1.0", "Your appointment is confirmed for tomorrow at ten am. Please call me when you reach home.")
        self.run_analysis()

    def run_analysis(self):
        result = analyse_message(self.input.get("1.0", "end"))
        color = "#b42318" if result["risk"] >= 70 else ("#b76e00" if result["risk"] >= 40 else "#24704a")
        self.status.config(text=result["level"], fg=color)
        self.score.config(text=f"Risk score: {result['risk']} / 100", fg=color)
        self.bar["value"] = result["risk"]
        self.reasons.delete("1.0", "end")
        self.reasons.insert("1.0", "\n".join("• " + x for x in result["reasons"]))
        self.advice.delete("1.0", "end")
        self.advice.insert("1.0", "\n".join("• " + x for x in result["advice"]))

if __name__ == "__main__":
    root = tk.Tk()
    ScamShieldApp(root)
    root.mainloop()
