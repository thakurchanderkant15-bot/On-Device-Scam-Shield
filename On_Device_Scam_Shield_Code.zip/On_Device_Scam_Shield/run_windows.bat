@echo off
python scam_shield.py
pause
